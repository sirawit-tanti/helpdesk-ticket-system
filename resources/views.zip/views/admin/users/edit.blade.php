@extends('layouts.app')

@section('title', 'Edit User - Helpdesk Ticket System')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="h3 mb-1">Edit User</h1>
        <p class="text-muted mb-0">
            Update user account details.
        </p>
    </div>

    <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
        Back to Users
    </a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form method="POST" action="{{ route('admin.users.update', $user) }}">
            @csrf
            @method('PUT')

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="name" class="form-label">
                        Name <span class="text-danger">*</span>
                    </label>

                    <input type="text" name="name" id="name" value="{{ old('name', $user->name) }}"
                        class="form-control @error('name') is-invalid @enderror" required>

                    @error('name')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                <div class="col-md-6 mb-3">
                    <label for="email" class="form-label">
                        Email <span class="text-danger">*</span>
                    </label>

                    <input type="email" name="email" id="email" value="{{ old('email', $user->email) }}"
                        class="form-control @error('email') is-invalid @enderror" required>

                    @error('email')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="role_id" class="form-label">
                        Role <span class="text-danger">*</span>
                    </label>

                    <select name="role_id" id="role_id" class="form-select @error('role_id') is-invalid @enderror"
                        required>
                        @foreach($roles as $role)
                        <option value="{{ $role->id }}" @selected(old('role_id', $user->role_id) == $role->id)
                            >
                            {{ $role->display_name }}
                        </option>
                        @endforeach
                    </select>

                    @error('role_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                <div class="col-md-6 mb-3">
                    <label for="department_id" class="form-label">
                        Department
                    </label>

                    <select name="department_id" id="department_id"
                        class="form-select @error('department_id') is-invalid @enderror">
                        <option value="">Select department</option>

                        @foreach($departments as $department)
                        <option value="{{ $department->id }}" @selected(old('department_id', $user->department_id) ==
                            $department->id)
                            >
                            {{ $department->name }}
                        </option>
                        @endforeach
                    </select>

                    @error('department_id')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>
            </div>

            <hr>

            <p class="text-muted small">
                Leave password fields empty if you do not want to change the password.
            </p>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="password" class="form-label">
                        New Password
                    </label>

                    <input type="password" name="password" id="password"
                        class="form-control @error('password') is-invalid @enderror">

                    @error('password')
                    <div class="invalid-feedback">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                <div class="col-md-6 mb-3">
                    <label for="password_confirmation" class="form-label">
                        Confirm New Password
                    </label>

                    <input type="password" name="password_confirmation" id="password_confirmation" class="form-control">
                </div>
            </div>

            <div class="form-check mb-3">
                <input type="checkbox" name="is_active" id="is_active" value="1" class="form-check-input"
                    @checked(old('is_active', $user->is_active))
                >

                <label for="is_active" class="form-check-label">
                    Active
                </label>
            </div>

            <div class="d-flex justify-content-end gap-2">
                <a href="{{ route('admin.users.index') }}" class="btn btn-outline-secondary">
                    Cancel
                </a>

                <button type="submit" class="btn btn-primary">
                    Save Changes
                </button>
            </div>
        </form>
    </div>
</div>
@endsection